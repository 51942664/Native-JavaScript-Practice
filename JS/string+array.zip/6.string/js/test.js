[
	{
        mainClassify: "手机 电话卡",
        goods:[
            {
                name: "小米6",
                imgSrc: "http://www.mi.com/image/xiaomi.jpg",
                hrefURL: "http://www.mi.com/pages/xiaomi6.html"
            },
            {
                name: "小米7",
                imgSrc: "http://www.mi.com/image/xiaomi2.jpg",
                hrefURL: "http://www.mi.com/pages/xiaomi7.html"
            }
        ]
    },
    {
        mainClassify: "笔记本 平板",
        goods:[
            {
                name: "小米6",
                imgSrc: "http://www.mi.com/image/xiaomi.jpg",
                hrefURL: "http://www.mi.com/pages/xiaomi6.html"
            },
            {
                name: "小米7",
                imgSrc: "http://www.mi.com/image/xiaomi2.jpg",
                hrefURL: "http://www.mi.com/pages/xiaomi7.html"
            }
        ]
    }
]